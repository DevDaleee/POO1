c = list(range(0, 10))
print("Lista Normal", c)
novalista = reversed(c)
print("Lista Reorganizada: ")
for x in novalista:
    print(x)