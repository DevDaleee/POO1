#Interativa
num = int(input())
fat = 1
i = 2
while i <= num:
  fat = fat*i
  i = i + 1
print(fat)